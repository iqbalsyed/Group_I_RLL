package com.util;

import java.io.File;
import java.io.IOException;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

	public class ItestListenerClass implements ITestListener  {
		static WebDriver driver;
		
		public void onTestStart(ITestResult result) {
			
			System.out.println("Test Method start");
		
		}

		public void onTestSuccess(ITestResult result) {
			
			System.out.println("Test Method success");
		
		}

		public void onTestFailure(ITestResult result) {
			
			try{
				// To create reference of TakesScreenshot
				TakesScreenshot screenshot=(TakesScreenshot)driver;
				// Call method to capture screenshot
				File src=screenshot.getScreenshotAs(OutputType.FILE);
				// Copy files to specific location 
				// result.getName() will return name of test case so that screenshot name will be same as test case name
				FileUtils.copyFile(src, new File("C:\\Users\\Predator\\eclipse-workspace\\Team1_Group_Project\\Group_I_FirstCry\\Group_I_FirstCry\\Group_I_FirstCry\\Screenshots"+result.getName()+".png"));
				System.out.println("Successfully captured a screenshot");
			}catch (Exception e){
				System.out.println("Exception while taking screenshot "+e.getMessage());
			} 
		
		}

		public void onTestSkipped(ITestResult result) {
			
			System.out.println("Test Method skipped");
			
		}

		public void onTestFailedWithTimeout(ITestResult result) {
			
			System.out.println("Test Method fail with timeout");

		}

		public void onStart(ITestContext context) {
			
			System.out.println("Testing has started");
		
		}

		public void onFinish(ITestContext context) {
			
			System.out.println("Testing has finished");
		
		}


	}
