package com.util;

import org.apache.logging.log4j.LogManager;
import org.testng.IRetryAnalyzer;
import org.testng.ITestResult;

import org.apache.logging.log4j.Logger;


public class RetryAnalyzer implements IRetryAnalyzer {

	private static final Logger logger = LogManager.getLogger(RetryAnalyzer.class);
    private int retryCount = 0;
    private static final int MAX_RETRY_COUNT = 3; // Maximum retry count

    @Override
    public boolean retry(ITestResult result) {
    	if(!result.isSuccess()) {
    		logger.info ("Retrying test " + result.getName () + " with status " + getResultStatusName (
                    result.getStatus ()) + " for the " + (this.retryCount + 1) + " time(s).");
    		if (retryCount < MAX_RETRY_COUNT) {
    			this.retryCount++;
                return true;
    			
    		}
                
    	}
        return false;
    }
    public String getResultStatusName (final int status) {
        String resultName = null;
        if (status == 1) {
            resultName = "SUCCESS";
        }
        if (status == 2) {
            resultName = "FAILURE";
        }
        if (status == 3) {
            resultName = "SKIP";
        }
        return resultName;
    }




}
